package Service;

import DAO.UserDAO;
import Model.User;
import Util.Constants;
import Util.PasswordUtils;
import Util.SessionManager;
import Util.ValidationUtils;
import java.sql.SQLException;

/**
 * Servicio de autenticación y autorización.
 * Contiene la lógica de negocio para login, registro y gestión de sesiones.
 * NO accede directamente a DAO desde Controllers; los Controllers solo usan este Service.
 */
public class AuthService {
    
    private UserDAO userDAO;
    private SessionManager sessionManager;
    
    public AuthService() {
        this.userDAO = new UserDAO();
        this.sessionManager = SessionManager.getInstance();
    }
    
    /**
     * Autentica un usuario con email y contraseña.
     * Si las credenciales son válidas, inicia sesión automáticamente.
     * 
     * @param email correo del usuario
     * @param password contraseña del usuario
     * @return true si la autenticación es exitosa, false en caso contrario
     * @throws IllegalArgumentException si el email o contraseña son inválidos
     * @throws RuntimeException si ocurre un error en la base de datos
     */
    public boolean authenticate(String email, String password) throws IllegalArgumentException, RuntimeException {
        // Validar entrada
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("El correo no puede estar vacío.");
        }
        if (password == null || password.isEmpty()) {
            throw new IllegalArgumentException("La contraseña no puede estar vacía.");
        }
        
        try {
            // Buscar usuario por email
            User user = userDAO.findByEmail(email);
            
            if (user == null) {
                // Usuario no encontrado
                return false;
            }
            
            // Verificar contraseña
            if (PasswordUtils.verifyPassword(password, user.getPassword())) {
                // Contraseña correcta - iniciar sesión
                sessionManager.setCurrentUser(user);
                return true;
            }
            
            // Contraseña incorrecta
            return false;
            
        } catch (SQLException e) {
            throw new RuntimeException(Constants.ERROR_DATABASE, e);
        }
    }
    
    /**
     * Registra un nuevo usuario con validación de datos.
     * 
     * @param nombre nombre del usuario
     * @param correo correo electrónico del usuario
     * @param contraseña contraseña del usuario
     * @return usuario creado si es exitoso, null en caso contrario
     * @throws IllegalArgumentException si los datos no son válidos
     * @throws RuntimeException si ocurre un error en la base de datos
     */
    public User registerUser(String nombre, String correo, String contraseña) 
            throws IllegalArgumentException, RuntimeException {
        
        // Validar nombre
        if (!ValidationUtils.isValidName(nombre)) {
            throw new IllegalArgumentException(Constants.ERROR_NAME_EMPTY);
        }
        
        // Validar email
        if (!ValidationUtils.isValidEmail(correo)) {
            throw new IllegalArgumentException(Constants.ERROR_INVALID_EMAIL);
        }
        
        // Validar contraseña
        if (!ValidationUtils.isValidPassword(contraseña)) {
            throw new IllegalArgumentException(Constants.ERROR_PASSWORD_TOO_SHORT);
        }
        
        try {
            // Verificar si el email ya existe
            if (userDAO.emailExists(correo)) {
                throw new IllegalArgumentException(Constants.ERROR_EMAIL_ALREADY_EXISTS);
            }
            
            // Crear nuevo usuario
            User newUser = new User();
            newUser.setName(nombre);
            newUser.setEmail(correo);
            newUser.setPassword(contraseña);
            newUser.setProfilePhoto("");
            newUser.setStatus("");
            newUser.setConnected(false);
            
            // Guardar en base de datos
            User createdUser = userDAO.create(newUser);
            
            if (createdUser == null) {
                throw new RuntimeException(Constants.ERROR_DATABASE);
            }
            
            return createdUser;
            
        } catch (SQLException e) {
            throw new RuntimeException(Constants.ERROR_DATABASE, e);
        }
    }
    
    /**
     * Cierra la sesión del usuario actual.
     */
    public void logout() {
        sessionManager.clearSession();
    }
    
    /**
     * Verifica si existe una sesión activa.
     * 
     * @return true si hay un usuario autenticado, false en caso contrario
     */
    public boolean isSessionActive() {
        return sessionManager.isSessionActive();
    }
    
    /**
     * Obtiene el usuario autenticado actualmente.
     * 
     * @return usuario autenticado o null si no hay sesión activa
     */
    public User getCurrentUser() {
        return sessionManager.getCurrentUser();
    }
}
