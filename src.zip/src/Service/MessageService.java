package Service;

import DAO.MessageDAO;
import Model.Message;
import Util.ValidationUtils;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Servicio de negocio para gestionar mensajes.
 * Coordina operaciones entre MessageDAO y el controlador.
 * Valida contenido de mensajes antes de persistir.
 */
public class MessageService {
    
    private MessageDAO messageDAO;
    
    public MessageService() {
        this.messageDAO = new MessageDAO();
    }
    
    /**
     * Envía un nuevo mensaje (lo guarda en la base de datos).
     * Valida que el contenido no esté vacío.
     * 
     * @param message Objeto Message con datos del mensaje
     * @return true si el mensaje se envió exitosamente
     * @throws IllegalArgumentException si el contenido está vacío
     * @throws RuntimeException si hay error en la base de datos
     */
    public boolean sendMessage(Message message) {
        try {
            // Validar que el contenido no esté vacío
            if (message.getContent() == null || message.getContent().trim().isEmpty()) {
                throw new IllegalArgumentException("El contenido del mensaje no puede estar vacío.");
            }
            
            // Validar que la conversación y remitente sean válidos
            if (message.getConversationId() <= 0 || message.getSenderId() <= 0) {
                throw new IllegalArgumentException("ID de conversación y remitente requeridos.");
            }
            
            // Establecer timestamp y estado por defecto si no están definidos
            if (message.getTimestamp() == null) {
                message.setTimestamp(LocalDateTime.now());
            }
            if (message.getStatus() == null) {
                message.setStatus("SENT");
            }
            
            return messageDAO.save(message);
        } catch (SQLException e) {
            throw new RuntimeException("Error al enviar mensaje: " + e.getMessage(), e);
        }
    }
    
    /**
     * Obtiene todos los mensajes de una conversación.
     * 
     * @param conversationId ID de la conversación
     * @return Lista de mensajes ordenados por timestamp
     * @throws RuntimeException si hay error en la base de datos
     */
    public List<Message> getMessages(int conversationId) {
        try {
            return messageDAO.findByConversation(conversationId);
        } catch (SQLException e) {
            throw new RuntimeException("Error al obtener mensajes: " + e.getMessage(), e);
        }
    }
    
    /**
     * Obtiene un mensaje específico por su ID.
     * 
     * @param messageId ID del mensaje
     * @return Objeto Message o null si no existe
     * @throws RuntimeException si hay error en la base de datos
     */
    public Message getMessage(int messageId) {
        try {
            return messageDAO.findById(messageId);
        } catch (SQLException e) {
            throw new RuntimeException("Error al obtener mensaje: " + e.getMessage(), e);
        }
    }
    
    /**
     * Actualiza el estado de un mensaje.
     * Estados válidos: SENT, DELIVERED, READ
     * 
     * @param messageId ID del mensaje
     * @param status nuevo estado
     * @return true si la actualización fue exitosa
     * @throws RuntimeException si hay error en la base de datos
     */
    public boolean updateMessageStatus(int messageId, String status) {
        try {
            if (status == null || status.trim().isEmpty()) {
                throw new IllegalArgumentException("El estado del mensaje no puede estar vacío.");
            }
            return messageDAO.updateStatus(messageId, status);
        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar estado del mensaje: " + e.getMessage(), e);
        }
    }
    
    /**
     * Elimina un mensaje.
     * 
     * @param messageId ID del mensaje a eliminar
     * @return true si la eliminación fue exitosa
     * @throws RuntimeException si hay error en la base de datos
     */
    public boolean deleteMessage(int messageId) {
        try {
            return messageDAO.delete(messageId);
        } catch (SQLException e) {
            throw new RuntimeException("Error al eliminar mensaje: " + e.getMessage(), e);
        }
    }
}
