package Util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Utilidad para el hash y verificación segura de contraseñas.
 * Utiliza SHA-256 con salt para mayor seguridad.
 */
public class PasswordUtils {
    
    private static final String ALGORITHM = "SHA-256";
    private static final int SALT_LENGTH = 16;
    
    /**
     * Genera un hash seguro de la contraseña con salt.
     * El formato retornado es: salt:hash (codificado en Base64)
     * 
     * @param password contraseña en texto plano
     * @return hash de la contraseña con salt en formato "salt:hash"
     * @throws RuntimeException si ocurre un error al generar el hash
     */
    public static String hashPassword(String password) {
        try {
            // Generar salt aleatorio
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[SALT_LENGTH];
            random.nextBytes(salt);
            
            // Generar hash
            MessageDigest digest = MessageDigest.getInstance(ALGORITHM);
            digest.update(salt);
            byte[] hashedPassword = digest.digest(password.getBytes());
            
            // Codificar salt y hash en Base64 y retornar como "salt:hash"
            String saltEncoded = Base64.getEncoder().encodeToString(salt);
            String hashEncoded = Base64.getEncoder().encodeToString(hashedPassword);
            
            return saltEncoded + ":" + hashEncoded;
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error al generar hash de contraseña", e);
        }
    }
    
    /**
     * Verifica si la contraseña en texto plano coincide con el hash almacenado.
     * 
     * @param password contraseña en texto plano a verificar
     * @param storedHash hash almacenado en formato "salt:hash"
     * @return true si la contraseña coincide, false en caso contrario
     * @throws RuntimeException si ocurre un error durante la verificación
     */
    public static boolean verifyPassword(String password, String storedHash) {
        try {
            // Separar salt y hash del valor almacenado
            String[] parts = storedHash.split(":");
            if (parts.length != 2) {
                return false;
            }
            
            String saltEncoded = parts[0];
            String hashEncoded = parts[1];
            
            // Decodificar salt
            byte[] salt = Base64.getDecoder().decode(saltEncoded);
            
            // Generar hash de la contraseña proporcionada usando el salt almacenado
            MessageDigest digest = MessageDigest.getInstance(ALGORITHM);
            digest.update(salt);
            byte[] hashedPassword = digest.digest(password.getBytes());
            
            // Codificar el hash generado
            String generatedHash = Base64.getEncoder().encodeToString(hashedPassword);
            
            // Comparar con el hash almacenado
            return generatedHash.equals(hashEncoded);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error al verificar contraseña", e);
        }
    }
}
