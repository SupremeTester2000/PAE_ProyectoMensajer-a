package Util;

import java.util.regex.Pattern;

/**
 * Utilidad para validación de entrada de datos.
 */
public class ValidationUtils {
    
    private static final Pattern EMAIL_PATTERN = Pattern.compile(Constants.REGEX_EMAIL);
    
    /**
     * Valida que un correo electrónico tenga formato válido.
     * 
     * @param email correo a validar
     * @return true si es válido, false en caso contrario
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        if (email.length() > Constants.MAX_EMAIL_LENGTH) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email).matches();
    }
    
    /**
     * Valida que una contraseña cumpla los requisitos mínimos.
     * 
     * @param password contraseña a validar
     * @return true si es válida, false en caso contrario
     */
    public static boolean isValidPassword(String password) {
        if (password == null || password.isEmpty()) {
            return false;
        }
        if (password.length() < Constants.MIN_PASSWORD_LENGTH) {
            return false;
        }
        return password.length() <= Constants.MAX_PASSWORD_LENGTH;
    }
    
    /**
     * Valida que un nombre no esté vacío.
     * 
     * @param name nombre a validar
     * @return true si es válido, false en caso contrario
     */
    public static boolean isValidName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        if (name.length() > Constants.MAX_NAME_LENGTH) {
            return false;
        }
        return true;
    }
}
