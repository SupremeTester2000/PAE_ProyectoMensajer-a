package Util;

import Model.User;

/**
 * Gestiona la sesión del usuario autenticado en memoria durante la ejecución de la aplicación.
 * Utiliza el patrón Singleton para garantizar una única instancia.
 */
public class SessionManager {
    
    private static SessionManager instance;
    private User currentUser;
    
    private SessionManager() { }
    
    /**
     * Obtiene la instancia única de SessionManager.
     * @return instancia de SessionManager
     */
    public static synchronized SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }
    
    /**
     * Establece el usuario autenticado en la sesión actual.
     * @param user usuario autenticado
     */
    public void setCurrentUser(User user) {
        this.currentUser = user;
    }
    
    /**
     * Obtiene el usuario autenticado en la sesión actual.
     * @return usuario autenticado o null si no hay sesión activa
     */
    public User getCurrentUser() {
        return this.currentUser;
    }
    
    /**
     * Verifica si existe una sesión activa.
     * @return true si hay usuario autenticado, false en caso contrario
     */
    public boolean isSessionActive() {
        return this.currentUser != null;
    }
    
    /**
     * Limpia la sesión actual, cerrando la autenticación del usuario.
     */
    public void clearSession() {
        this.currentUser = null;
    }
}
