package DAO;

import Model.Attachment;

public class AttachmentDAO {

    public boolean save(Attachment attachment){return false;}
    
    public Attachment findById(int id){return null;}
    
    public boolean delete(int id){return false;}
}
