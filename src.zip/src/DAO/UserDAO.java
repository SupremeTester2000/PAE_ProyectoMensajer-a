package DAO;

import Config.DatabaseConfig;
import Model.User;
import Util.PasswordUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object para la entidad Usuario. Maneja todas las operaciones de
 * base de datos relacionadas con usuarios.
 */
public class UserDAO {

    /**
     * Busca un usuario por su ID.
     *
     * @param id ID del usuario
     * @return Usuario encontrado o null si no existe
     * @throws SQLException si ocurre un error en la base de datos
     */
    public User findById(int id) throws SQLException {
        String sql = "SELECT id, name, email, password, profile_photo, status, connected FROM users WHERE id = ?";
        try (Connection conn = DatabaseConfig.getInstance().getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToUser(rs);
                }
            }
        }
        return null;
    }

    /**
     * Busca un usuario por su correo electrónico.
     *
     * @param email correo electrónico del usuario
     * @return Usuario encontrado o null si no existe
     * @throws SQLException si ocurre un error en la base de datos
     */
    public User findByEmail(String email) throws SQLException {
        String sql = "SELECT id, name, email, password, profile_photo, status, connected FROM users WHERE email = ?";
        try (Connection conn = DatabaseConfig.getInstance().getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToUser(rs);
                }
            }
        }
        return null;
    }

    /**
     * Verifica si un correo electrónico ya está registrado.
     *
     * @param email correo a verificar
     * @return true si el correo existe, false en caso contrario
     * @throws SQLException si ocurre un error en la base de datos
     */
    public boolean emailExists(String email) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        try (Connection conn = DatabaseConfig.getInstance().getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    /**
     * Crea un nuevo usuario en la base de datos. La contraseña se hashea antes
     * de almacenarla.
     *
     * @param user usuario a crear
     * @return usuario creado con su ID generado, o null si la operación falló
     * @throws SQLException si ocurre un error en la base de datos
     */
    public User create(User user) throws SQLException {
        // Hash de la contraseña antes de guardar
        String hashedPassword = PasswordUtils.hashPassword(user.getPassword());

        String sql = """
           INSERT INTO users
           (
            name,
            email,
            password,
            profile_photo,
            status,
            connected
            )
            VALUES (?, ?, ?, ?, ?, ?)
    """;
        try (Connection conn = DatabaseConfig.getInstance().getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, user.getName());
            pstmt.setString(2, user.getEmail());
            pstmt.setString(3, hashedPassword);
            pstmt.setString(4,
                    user.getProfilePhoto() != null
                    ? user.getProfilePhoto()
                    : null);

            pstmt.setString(5,
                    user.getStatus() != null
                    ? user.getStatus()
                    : "Disponible");

            pstmt.setBoolean(6, false);

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int generatedId = generatedKeys.getInt(1);
                        user.setId(generatedId);
                        // Retornar el usuario sin la contraseña en texto plano (solo el hash)
                        user.setPassword(hashedPassword);
                        return user;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Obtiene todos los usuarios de la base de datos.
     *
     * @return lista de usuarios
     */
    public List<User> findAll() {
        return null;
    }

    /**
     * Obtiene todos los usuarios excepto el indicado.
     *
     * @param excludedUserId usuario que no debe incluirse
     * @return lista de usuarios disponibles
     * @throws SQLException si ocurre un error en la base de datos
     */
    public List<User> findAllExcept(int excludedUserId) throws SQLException {
        List<User> users = new ArrayList<>();
        String sql = "SELECT id, name, email, password, profile_photo, status, connected "
                + "FROM users "
                + "WHERE id != ? "
                + "ORDER BY name ASC";

        try (Connection conn = DatabaseConfig.getInstance().getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, excludedUserId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    users.add(mapResultSetToUser(rs));
                }
            }
        }

        return users;
    }

    /**
     * Busca usuarios por nombre o correo electronico.
     *
     * @param keyword termino de busqueda
     * @param excludedUserId usuario que no debe incluirse en resultados
     * @return lista de usuarios encontrados
     * @throws SQLException si ocurre un error en la base de datos
     */
    public List<User> searchByKeyword(String keyword, int excludedUserId) throws SQLException {
        List<User> users = new ArrayList<>();
        String sql = "SELECT id, name, email, password, profile_photo, status, connected "
                + "FROM users "
                + "WHERE id != ? AND (name ILIKE ? OR email ILIKE ?) "
                + "ORDER BY name ASC";

        try (Connection conn = DatabaseConfig.getInstance().getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            String pattern = "%" + keyword + "%";
            pstmt.setInt(1, excludedUserId);
            pstmt.setString(2, pattern);
            pstmt.setString(3, pattern);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    users.add(mapResultSetToUser(rs));
                }
            }
        }

        return users;
    }

    /**
     * Actualiza un usuario existente.
     *
     * @param user usuario a actualizar
     * @return true si se actualizó exitosamente
     */
    public boolean update(User user) {
        return false;
    }

    /**
     * Elimina un usuario por su ID.
     *
     * @param id ID del usuario a eliminar
     * @return true si se eliminó exitosamente
     */
    public boolean delete(int id) {
        return false;
    }

    /**
     * Convierte una fila del ResultSet en un objeto User.
     *
     * @param rs ResultSet con los datos del usuario
     * @return objeto User poblado con los datos
     * @throws SQLException si ocurre un error al leer los datos
     */
    private User mapResultSetToUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setId(rs.getInt("id"));
        user.setName(rs.getString("name"));
        user.setEmail(rs.getString("email"));
        user.setPassword(rs.getString("password"));
        user.setProfilePhoto(rs.getString("profile_photo"));
        user.setStatus(rs.getString("status"));
        user.setConnected(rs.getBoolean("connected"));
        return user;
    }
}
