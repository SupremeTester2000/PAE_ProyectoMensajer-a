package Controllers;

import Model.Conversation;
import Model.Message;
import Model.User;
import Service.MessageService;
import Util.SessionManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXML;
import java.io.IOException;

/**
 * Controlador para ChatView.
 * Gestiona el historial de mensajes y el envio de nuevos mensajes.
 */
public class ChatController {
    
    @FXML
    private Label lblConversationName;
    
    @FXML
    private ListView<String> messageList;
    
    @FXML
    private TextArea txtMessageInput;
    
    @FXML
    private Button btnContactInfo;
    
    @FXML
    private Button btnGroupInfo;
    
    @FXML
    private Button btnDelete;
    
    private MessageService messageService;
    private Conversation conversation;
    private DashboardController dashboardController;
    private Stage stage;
    private User currentUser;
    private ObservableList<String> messageTexts;
    private List<Message> messages;
    private DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    private DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    
    /**
     * Metodo de inicializacion llamado automaticamente despues de cargar el FXML.
     */
    @FXML
    public void initialize() {
        this.messageService = new MessageService();
        this.currentUser = SessionManager.getInstance().getCurrentUser();
        this.messageTexts = FXCollections.observableArrayList();
        
        if (messageList != null) {
            messageList.setItems(messageTexts);
        }
    }
    
    /**
     * Setea la conversacion actual.
     * 
     * @param conversation conversacion a mostrar
     */
    public void setConversation(Conversation conversation) {
        this.conversation = conversation;
        
        // Mostrar nombre de la conversacion
        if (lblConversationName != null && conversation != null) {
            String displayName = conversation.getGroupName();
            if (displayName == null || displayName.isEmpty()) {
                displayName = "Conversacion Privada";
            }
            lblConversationName.setText(displayName);
        }
        
        // Mostrar botones segun tipo de conversacion
        if (conversation != null) {
            if ("PRIVATE".equals(conversation.getType())) {
                if (btnContactInfo != null) btnContactInfo.setVisible(true);
                if (btnGroupInfo != null) btnGroupInfo.setVisible(false);
            } else if ("GROUP".equals(conversation.getType())) {
                if (btnContactInfo != null) btnContactInfo.setVisible(false);
                if (btnGroupInfo != null) btnGroupInfo.setVisible(true);
            }
        }
        
        // Cargar mensajes
        loadMessages();
    }
    
    /**
     * Setea el controlador del Dashboard (para volver).
     * 
     * @param dashboardController referencia al DashboardController
     */
    public void setDashboardController(DashboardController dashboardController) {
        this.dashboardController = dashboardController;
    }
    
    /**
     * Setea el Stage primario.
     * 
     * @param stage Stage primario
     */
    public void setStage(Stage stage) {
        this.stage = stage;
    }
    
    /**
     * Carga todos los mensajes de la conversacion.
     */
    @FXML
    private void loadMessages() {
        if (conversation == null || currentUser == null) {
            showError("No hay conversacion o usuario seleccionado.");
            return;
        }
        
        try {
            messages = messageService.getMessages(conversation.getId());
            updateMessageList(messages);
        } catch (Exception e) {
            showError("Error al cargar mensajes: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Actualiza la ListView con los mensajes.
     * 
     * @param messagesList lista de mensajes a mostrar
     */
    private void updateMessageList(List<Message> messagesList) {
        messageTexts.clear();
        
        for (Message msg : messagesList) {
            String senderName = (msg.getSenderId() == currentUser.getId()) ? "Tu" : "Usuario";
            String time = msg.getTimestamp() != null ? msg.getTimestamp().format(timeFormatter) : "--:--";
            String displayText = String.format("[%s] %s: %s", time, senderName, msg.getContent());
            messageTexts.add(displayText);
        }
    }
    
    /**
     * Envia un nuevo mensaje.
     */
    @FXML
    private void sendMessage() {
        if (conversation == null || currentUser == null) {
            showError("No hay conversacion o usuario seleccionado.");
            return;
        }
        
        String messageContent = txtMessageInput != null ? txtMessageInput.getText() : "";
        
        if (messageContent == null || messageContent.trim().isEmpty()) {
            showError("El mensaje no puede estar vacio.");
            return;
        }
        
        try {
            Message message = new Message();
            message.setConversationId(conversation.getId());
            message.setSenderId(currentUser.getId());
            message.setContent(messageContent);
            message.setStatus("SENT");
            
            boolean success = messageService.sendMessage(message);
            
            if (success) {
                // Limpiar campo de entrada
                if (txtMessageInput != null) {
                    txtMessageInput.clear();
                }
                
                // Recargar mensajes
                loadMessages();
                
                // Scroll al ultimo mensaje
                if (messageList != null && messageTexts.size() > 0) {
                    messageList.scrollTo(messageTexts.size() - 1);
                }
            } else {
                showError("No se pudo enviar el mensaje.");
            }
        } catch (IllegalArgumentException e) {
            showError(e.getMessage());
        } catch (Exception e) {
            showError("Error al enviar mensaje: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Abre la informacion del contacto (para conversaciones privadas).
     */
    @FXML
    private void openContactInfo() {
        showInfo("Info Contacto", "Informacion del contacto - Implementacion futura");
    }
    
    /**
     * Abre la informacion del grupo (para conversaciones de grupo).
     */
    @FXML
    private void openGroupInfo() {
        showInfo("Info Grupo", "Informacion del grupo - Implementacion futura");
    }
    
    /**
     * Elimina un mensaje (implementacion futura).
     */
    @FXML
    private void deleteMessage() {
        showInfo("Eliminar", "Funcionalidad de eliminar mensaje - Implementacion futura");
    }
    
    /**
     * Vuelve a la vista del Dashboard.
     */
    @FXML
    private void returnToDashboard() {

        try {

            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/View/DashboardView.fxml"));

            Parent root = loader.load();

            Stage currentStage
                    = (Stage) messageList.getScene().getWindow();

            Scene scene = new Scene(root);

            currentStage.setScene(scene);

            currentStage.setTitle("ChatConnect - Dashboard");

            currentStage.show();

        } catch (IOException e) {

            showError(
                    "Error al volver al Dashboard: "
                    + e.getMessage());

            e.printStackTrace();
        }
    }
    
    /**
     * Muestra un mensaje de error.
     * 
     * @param message mensaje de error
     */
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    /**
     * Muestra un mensaje de informacion.
     * 
     * @param title titulo
     * @param message mensaje
     */
    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
