package Controllers;

import Model.Conversation;
import Model.User;
import Service.ConversationService;
import Util.SessionManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DashboardController {

    @FXML
    private Label lblUsername;

    @FXML
    private TextField txtSearch;

    @FXML
    private ListView<String> conversationList;

    private final ConversationService conversationService;

    private User currentUser;

    private ObservableList<String> conversationNames;

    private List<Conversation> currentConversations;

    private Stage stage;

    public DashboardController() {
        this.conversationService = new ConversationService();
    }

    @FXML
    public void initialize() {

        currentUser = SessionManager.getInstance().getCurrentUser();

        conversationNames = FXCollections.observableArrayList();

        currentConversations = new ArrayList<>();

        if (currentUser != null && lblUsername != null) {
            lblUsername.setText(currentUser.getName());
        }

        if (conversationList != null) {

            conversationList.setItems(conversationNames);

            conversationList.setOnMouseClicked(event -> {

                if (event.getClickCount() == 2
                        && conversationList.getSelectionModel().getSelectedIndex() >= 0) {

                    openSelectedConversation();
                }
            });
        }

        loadConversations();
    }

    /**
     * Carga todas las conversaciones del usuario autenticado.
     */
    private void loadConversations() {

        if (currentUser == null) {
            showError("Usuario no autenticado.");
            return;
        }

        try {

            currentConversations =
                    conversationService.getUserConversations(
                            currentUser.getId());

            if (currentConversations == null) {
                currentConversations = new ArrayList<>();
            }

            updateConversationList(currentConversations);

        } catch (Exception e) {

            showError("Error al cargar conversaciones.");

            e.printStackTrace();
        }
    }

    public void refreshConversations() {
        loadConversations();
    }

    /**
     * Búsqueda desde el TextField.
     */
    @FXML
    private void searchConversations() {

        if (currentUser == null) {
            return;
        }

        try {

            String searchTerm =
                    txtSearch != null
                            ? txtSearch.getText().trim()
                            : "";

            currentConversations =
                    conversationService.searchConversations(
                            currentUser.getId(),
                            searchTerm);

            if (currentConversations == null) {
                currentConversations = new ArrayList<>();
            }

            updateConversationList(currentConversations);

        } catch (Exception e) {

            showError("Error al buscar conversaciones.");

            e.printStackTrace();
        }
    }

    /**
     * Actualiza la ListView.
     */
    private void updateConversationList(
            List<Conversation> conversations) {

        conversationNames.clear();

        for (Conversation conversation : conversations) {

            String displayName =
                    conversationService.getConversationDisplayName(
                            conversation.getId(),
                            currentUser.getId());

            conversationNames.add(displayName);
        }
    }

    /**
     * Abre la conversación seleccionada.
     */
    private void openSelectedConversation() {

        if (currentConversations == null
                || currentConversations.isEmpty()) {

            showError("No existen conversaciones.");
            return;
        }

        int selectedIndex =
                conversationList.getSelectionModel()
                        .getSelectedIndex();

        if (selectedIndex < 0
                || selectedIndex >= currentConversations.size()) {

            showError("Selecciona una conversación.");
            return;
        }

        Conversation selectedConversation =
                currentConversations.get(selectedIndex);

        try {

            loadChatView(selectedConversation);

        } catch (IOException e) {

            showError("No fue posible abrir la conversación.");

            e.printStackTrace();
        }
    }

    /**
     * Navega hacia ChatView.
     */
    private void loadChatView(
            Conversation conversation)
            throws IOException {

        if (stage == null) {
            stage = (Stage)
                    conversationList
                            .getScene()
                            .getWindow();
        }

        FXMLLoader loader =
                new FXMLLoader(
                        getClass().getResource(
                                "/View/ChatView.fxml"));

        Parent root = loader.load();

        ChatController controller =
                loader.getController();

        controller.setConversation(conversation);

        controller.setStage(stage);

        Scene scene = new Scene(root);

        stage.setScene(scene);

        stage.setTitle(
                "ChatConnect");
    }

    /**
     * Botón Perfil.
     */
    @FXML
    private void openProfile() {

        try {

            FXMLLoader loader =
                    new FXMLLoader(
                            getClass().getResource(
                                    "/View/ProfileView.fxml"));

            Parent root = loader.load();

            Stage profileStage = new Stage();
            profileStage.setTitle("ChatConnect - Perfil");
            profileStage.setScene(new Scene(root));
            profileStage.initOwner(
                    lblUsername
                            .getScene()
                            .getWindow());

            profileStage.showAndWait();

        } catch (IOException e) {

            showError("No fue posible abrir el perfil.");

            e.printStackTrace();
        }
    }

    @FXML
    private void openSearch() {

        try {

            FXMLLoader loader =
                    new FXMLLoader(
                            getClass().getResource(
                                    "/View/SearchView.fxml"));

            Parent root = loader.load();

            SearchController controller =
                    loader.getController();

            Stage searchStage = new Stage();
            searchStage.setTitle("ChatConnect - Buscar usuarios");
            searchStage.setScene(new Scene(root));
            searchStage.initOwner(
                    conversationList
                            .getScene()
                            .getWindow());

            controller.setDashboardController(this);
            controller.setStage(searchStage);

            searchStage.showAndWait();
            refreshConversations();

        } catch (IOException e) {

            showError("No fue posible abrir la busqueda de usuarios.");

            e.printStackTrace();
        }
    }

    @FXML
    private void openCreateGroup() {

        try {

            FXMLLoader loader =
                    new FXMLLoader(
                            getClass().getResource(
                                    "/View/CreateGroupView.fxml"));

            Parent root = loader.load();

            CreateGroupController controller =
                    loader.getController();

            Stage groupStage = new Stage();
            groupStage.setTitle("ChatConnect - Crear grupo");
            groupStage.setScene(new Scene(root));
            groupStage.initOwner(
                    conversationList
                            .getScene()
                            .getWindow());

            controller.setDashboardController(this);
            controller.setStage(groupStage);

            groupStage.showAndWait();
            refreshConversations();

        } catch (IOException e) {

            showError("No fue posible abrir la creación de grupo.");

            e.printStackTrace();
        }
    }

    /**
     * Botón Salir.
     */
    @FXML
    private void logout() {

        try {

            SessionManager
                    .getInstance()
                    .clearSession();

            FXMLLoader loader =
                    new FXMLLoader(
                            getClass().getResource(
                                    "/View/LoginView.fxml"));

            Parent root = loader.load();

            Stage currentStage =
                    (Stage) lblUsername
                            .getScene()
                            .getWindow();

            currentStage.setScene(
                    new Scene(root));

            currentStage.setTitle(
                    "ChatConnect - Login");

        } catch (IOException e) {

            showError(
                    "Error al cerrar sesión.");

            e.printStackTrace();
        }
    }

    /**
     * Permite reutilizar el Stage.
     */
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    private void showError(String message) {

        Alert alert =
                new Alert(Alert.AlertType.ERROR);

        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);

        alert.showAndWait();
    }

    private void showInfo(
            String title,
            String message) {

        Alert alert =
                new Alert(
                        Alert.AlertType.INFORMATION);

        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);

        alert.showAndWait();
    }
}
