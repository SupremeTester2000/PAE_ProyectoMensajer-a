package Controllers;

import Model.User;

public class ContactInfoController {
 
    public void initialize(){}
    
    public void loadContact(User user){}
    
    private void blockContact(){}
    
    private void startConversation(){}
}