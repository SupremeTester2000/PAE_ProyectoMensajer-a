package Controllers;

import Model.User;
import Service.AuthService;
import Util.Constants;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;

/**
 * Controlador para la vista de registro de usuarios (RegisterView).
 * Gestiona el proceso de creación de nuevas cuentas y validación de datos.
 */
public class RegisterController {
    
    @FXML
    private TextField nameField;
    
    @FXML
    private TextField emailField;
    
    @FXML
    private PasswordField passwordField;
    
    @FXML
    private PasswordField confirmPasswordField;
    
    @FXML
    private Button registerButton;
    
    @FXML
    private Button backButton;
    
    @FXML
    private Label errorLabel;
    
    @FXML
    private Label successLabel;
    
    private AuthService authService;
    private Stage stage;
    
    /**
     * Método de inicialización llamado automáticamente después de cargar el FXML.
     */
    @FXML
    public void initialize() {
        this.authService = new AuthService();
        
        // Limpiar mensajes iniciales
        if (errorLabel != null) {
            errorLabel.setText("");
        }
        if (successLabel != null) {
            successLabel.setText("");
        }
        
        // Configurar event handlers
        if (registerButton != null) {
            registerButton.setOnAction(event -> handleRegister());
        }
        
        if (backButton != null) {
            backButton.setOnAction(event -> handleBackToLogin());
        }
        
        // Permitir registro al presionar Enter en el último campo
        if (confirmPasswordField != null) {
            confirmPasswordField.setOnAction(event -> handleRegister());
        }
    }
    
    /**
     * Setea el Stage primario de la aplicación.
     * Este método se llama desde LoginController o el FXMLLoader.
     * 
     * @param stage Stage primario de la aplicación
     */
    public void setStage(Stage stage) {
        this.stage = stage;
    }
    
    /**
     * Maneja el evento de click en el botón "Registrarse".
     * Valida los datos y crea una nueva cuenta de usuario.
     */
    @FXML
    private void handleRegister() {
        try {
            // Validar campos no vacíos
            if (nameField == null || nameField.getText().trim().isEmpty()) {
                showError("Por favor ingresa tu nombre.");
                return;
            }
            
            if (emailField == null || emailField.getText().trim().isEmpty()) {
                showError("Por favor ingresa tu correo electrónico.");
                return;
            }
            
            if (passwordField == null || passwordField.getText().isEmpty()) {
                showError("Por favor ingresa una contraseña.");
                return;
            }
            
            if (confirmPasswordField == null || confirmPasswordField.getText().isEmpty()) {
                showError("Por favor confirma tu contraseña.");
                return;
            }
            
            // Validar que las contraseñas coincidan
            if (!passwordField.getText().equals(confirmPasswordField.getText())) {
                showError("Las contraseñas no coinciden.");
                return;
            }
            
            String nombre = nameField.getText().trim();
            String email = emailField.getText().trim();
            String password = passwordField.getText();
            
            // Intentar registrar usuario
            User newUser = authService.registerUser(nombre, email, password);
            
            if (newUser != null) {
                // Registro exitoso
                showSuccess(Constants.SUCCESS_REGISTRATION);
                
                // Limpiar campos
                nameField.clear();
                emailField.clear();
                passwordField.clear();
                confirmPasswordField.clear();
                
                // Esperar un momento y volver a LoginView
                new Thread(() -> {
                    try {
                        Thread.sleep(2000); // Mostrar el mensaje de éxito por 2 segundos
                        javafx.application.Platform.runLater(this::handleBackToLogin);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }).start();
            } else {
                showError(Constants.ERROR_DATABASE);
            }
            
        } catch (IllegalArgumentException e) {
            showError(e.getMessage());
        } catch (RuntimeException e) {
            showError(Constants.ERROR_DATABASE);
            e.printStackTrace();
        }
    }
    
    /**
     * Maneja el evento de click en el botón "Volver".
     * Navega de regreso a LoginView.
     */
    @FXML
    private void handleBackToLogin() {
        try {
            loadView("/View/LoginView.fxml", Constants.APP_NAME);
        } catch (IOException e) {
            showError("Error al cargar la vista de login: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Carga una nueva vista reemplazando la escena actual.
     * 
     * @param fxmlPath ruta del archivo FXML a cargar
     * @param title título de la ventana
     * @throws IOException si el archivo FXML no se encuentra
     */
    private void loadView(String fxmlPath, String title) throws IOException {
        // Si no tenemos Stage, intentar obtenerlo desde los campos
        if (stage == null) {
            if (registerButton != null) {
                stage = (Stage) registerButton.getScene().getWindow();
            } else if (emailField != null) {
                stage = (Stage) emailField.getScene().getWindow();
            }
        }
        
        if (stage == null) {
            throw new RuntimeException("No se pudo obtener el Stage de la aplicación.");
        }
        
        // Cargar el nuevo FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
        Parent root = loader.load();
        
        // Obtener el controlador si es necesario y setearle el Stage
        Object controller = loader.getController();
        if (controller instanceof LoginController) {
            ((LoginController) controller).setStage(stage);
        } else if (controller instanceof RegisterController) {
            ((RegisterController) controller).setStage(stage);
        }
        
        // Crear nueva escena
        Scene scene = new Scene(root);
        
        // Aplicar estilos si existen
        try {
            String css = getClass().getResource("/View/chatconnect.css").toExternalForm();
            scene.getStylesheets().add(css);
        } catch (NullPointerException e) {
            System.out.println("CSS no encontrado, continuando sin estilos.");
        }
        
        // Actualizar la escena y el título
        stage.setScene(scene);
        stage.setTitle(title);
    }
    
    /**
     * Muestra un mensaje de error al usuario.
     * 
     * @param message mensaje de error a mostrar
     */
    private void showError(String message) {
        if (errorLabel != null) {
            errorLabel.setText(message);
            errorLabel.setStyle("-fx-text-fill: red;");
        }
        
        // Limpiar etiqueta de éxito
        if (successLabel != null) {
            successLabel.setText("");
        }
    }
    
    /**
     * Muestra un mensaje de éxito al usuario.
     * 
     * @param message mensaje de éxito a mostrar
     */
    private void showSuccess(String message) {
        if (successLabel != null) {
            successLabel.setText(message);
            successLabel.setStyle("-fx-text-fill: green;");
        }
        
        // Limpiar etiqueta de error
        if (errorLabel != null) {
            errorLabel.setText("");
        }
    }
}